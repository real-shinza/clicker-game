#include "Texture.h"

Texture::Texture()
{
}

Texture::~Texture()
{
}
