#ifndef ENEMY_H
#define ENEMY_H

class Enemy
{
public:
    Enemy();
    ~Enemy();

    void Update();
    void Draw();
};

#endif
